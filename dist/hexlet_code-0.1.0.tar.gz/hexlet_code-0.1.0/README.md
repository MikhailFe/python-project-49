### Hexlet tests and linter status:
[![Actions Status](https://github.com/MikhailFe/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/MikhailFe/python-project-49/actions)

[![Maintainability](https://api.codeclimate.com/v1/badges/12aa77826c5da5e6b653/maintainability)](https://codeclimate.com/github/MikhailFe/python-project-49/maintainability)